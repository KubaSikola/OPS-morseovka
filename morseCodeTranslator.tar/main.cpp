#include "mbed.h"
#include <string>
#include "stm32746g_discovery_lcd.h"
DigitalOut myled(LED1);

const float delay_super_short = 0.2;
const float delay_short = 0.5;
const float delay_long = 1;
const char latinAlphabet[30] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '.', ',' };
const string morseAlphabet[30] = { ".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--..", ".-.-.-", "--..--" };

void dot(){
        myled = 1;
        wait(delay_short); 
        myled = 0; // 
        wait(delay_super_short); 

}

void dash(){
        myled = 1;
        wait(delay_long); 
        myled = 0; 
        wait(delay_super_short); 

}

void beep(string morseAlphabet){
    for(unsigned i = 0; i<morseAlphabet.length(); i++){
        if(morseAlphabet[i] == '-'){
            dot();
        }else{
            dash();
        }

    }
}
int main() {  
    
    string latinPhrase = "JakubSikola";

    BSP_LCD_Init();
    BSP_LCD_LayerDefaultInit(LTDC_ACTIVE_LAYER, LCD_FB_START_ADDRESS);
    BSP_LCD_SelectLayer(LTDC_ACTIVE_LAYER);
    BSP_LCD_Clear(LCD_COLOR_WHITE);
    BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
    BSP_LCD_DisplayStringAt(0, 1, (uint8_t *)"Jakub Sikola", CENTER_MODE);
    BSP_LCD_DisplayStringAt(0, 100, (uint8_t *)"Peter Spurny", CENTER_MODE);
        
    while(1) {
        for(unsigned i = 0; i<latinPhrase.length(); i++){
            for(int counter = 0; counter < 30; counter++){
                if(latinPhrase.at(i) == latinAlphabet[counter]){
                    beep(morseAlphabet[counter]);
                    break;
                }
            }
        }
    }
}
